import Foundation
import LumenCore
@MainActor final class Store: ConversationStore {
 var snapshot: ChatSnapshot
 init(_ snapshot: ChatSnapshot) { self.snapshot = snapshot }
 func load(accountID: String) throws -> ChatSnapshot { snapshot }
 func save(_ snapshot: ChatSnapshot, accountID: String) throws { self.snapshot = snapshot }
}
@main struct Repro {
 @MainActor static func main() throws {
  let msg = ChatMessage(id: "prefix2", role: .user, content: "Keep")
  var child = Conversation(id: "child", messages: [msg]); child.parentConversationID = "parent"; child.inheritedMessageIDs = [msg.id]
  let engine = ChatEngine(store: Store(ChatSnapshot(conversations: [child], pendingMessages: [child.id: [msg.id]])))
  let metadata: [String: Any] = ["ids": ["prefix1"], "nativeParent": "parent"]
  engine.applyRemoteMetadata(try WebChatCodec.conversation(id: "child", fields: metadata))
  let after = engine.savedConversations.first { $0.id == "child" }!
  print("inherited after listener:", after.inheritedMessageIDs as Any)
  let plan = try WebChatCodec.append(chat: after, messageIDs: [msg.id], remote: metadata, existingMessages: [:], sourceMetadata: ["deleted": true])
  print("missing source still written:", plan.messages.keys)
  let all = [ChatMessage(id: "system", role: .system, content: "Required instructions")] + (0..<100).map { ChatMessage(id: "m\($0)", role: $0 % 2 == 0 ? .user : .assistant, content: "Turn") }
  let ids = try HistoryPaging.pageIDs(orderedIDs: all.map(\.id), loadedIDs: [], older: false)
  let window = try ContextWindow.select(messages: all.filter { ids.contains($0.id) } + [ChatMessage(role: .user, content: "Next")])
  print("system retained after latest page:", window.messages.contains { $0.role == .system })
 }
}
