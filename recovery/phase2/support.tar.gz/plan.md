# Lumen Phase 2 Implementation Plan

> For agentic workers: execute inline with superpowers:executing-plans. The user authorized the entire phase in one continuous run, publishing each part when verified.

Goal: ship five usable native releases for everyday chat, each added to the existing SideStore source.
Architecture: extend the existing SwiftUI/LumenCore/Firebase split. Keep all local state account-scoped and durable; preserve web schemas and unowned fields. Native message revisions are immutable conversation versions grouped as one history item, so edits never destroy the earlier transcript.
Tech stack: Swift 6, SwiftUI iOS26, Firebase13.1.1, GoogleSignIn10.1.0, GitHub macOS26/Xcode26.6, SideStore.
Spec: user's accepted five-part outline in this conversation and HANDOFF.md.

## Global Constraints
- Native first; web fixes only. No bottom tabs. Minimal repository Markdown; this plan/ledger live in scratch.
- No production rules changes, privileged private account data or live paid inference in tests.
- Release 2.1 as0.3.0, 2.2 as0.3.1, 2.3 as0.3.2, 2.4 as0.3.3, 2.5 as0.3.4. Each exact main commit must pass native UI/backend/artifact gates before source publication.
- Develop the next part while prior CI runs, but merge its release only after the previous source update finishes. This prevents pending-main concurrency cancellation and preserves every feed version.
- Update HANDOFF before commits and meaningful transitions. Native inline implementation; one fresh reviewer per independently shipped part as required by executing-plans.

## Review Focus
- Earlier transcripts, unknown web metadata, citations and attachments survive edits/retries and restart.
- Old account, late streams, saves failing, stale history and queued operations cannot write into another account/chat.
- Temporary chat content never enters disk snapshots, preferences, cloud outboxes, search or restored state.
- Attachments have bounded validated bytes/types, safe filenames, protected durable storage, account ownership and provider-specific formats.
- Long histories retain order/context and pending local turns across paging, disconnects, process death and remote changes.

## Task 1 / 2.1: Message controls, versioned revisions, copy/share (0.3.0)
Files: Core ChatEngine, Conversation, ChatMessage, WebChatCodec; CloudChatSync; ChatView/MessageActionsView/RootView/SidebarView/WorkspaceView; Core MessageRevisionTests; UITests and local HTTP fixture; release metadata.
Interfaces: ChatEngine.editAndResend(messageID:text:apiKey:) and regenerate(messageID:apiKey:) -> Task<Void,Never>?; historyConversations groups immutable version chats; versions(for:) returns lineage alternatives. Conversation optional lineageRootID,parentConversationID,revisionLabel. ChatMessage optional sourceMessageID preserves edited attachment provenance.
- [ ] Tests first: edit earlier user prompt creates durable revised prefix/new reply, keeps original untouched, omits later context, and groups versions; regenerate/retry excludes selected/later failed replies without duplicating user; save failure/account switch/late stream retain isolation. Codec cloning preserves source files/citations and context fields, never mutates source and rejects tombstone parent.
- [ ] Run Swift tests; observe missing API/behavior RED, implement minimal revision pipeline and safe fork cloning in existing append transaction, then whole suite GREEN.
- [ ] Native user-message edit sheet, assistant copy/share/regenerate/retry actions, versions sheet; dismiss editors on account/chat change. No core UIKit dependencies.
- [ ] Add real SDK UI journey for edit, regenerate and returning to original; assert preserved original wire metadata in fixture verifier.
- [ ] Review, fix important findings with regression tests, bump0.3.0/notes/checkpoint, publish through CI, verify anonymous source/IPA.

## Task 2 / 2.2: History management/search (0.3.1)
Files: Core ChatMetadataMutation/ChatEngine/ConversationStore/WebChatCodec, CloudChatSync; Sidebar and HistorySearchView; Core history tests/UI/fixture; release metadata.
Interfaces: durable field-specific metadata outbox; rename/pin/archive operate across grouped lineage versions. Queries search normalized title and loaded message text with previews and archived scope. Cloud metadata patches only owned requested fields, never unowned data.
- [ ] RED: rename/pin/archive survive restart/remote snapshots, reject blank titles/save failures, preserve unrelated concurrent metadata, exclude archived by default; grouped versions stay together; search is case/diacritic insensitive and can find cached message content.
- [ ] Implement durable patches and native context actions/search/archived view, then Core suite GREEN.
- [ ] Real SDK UI journey and fixture backend assertions for metadata preservation; review, publish0.3.1 and verify source.

## Task 3 / 2.3: Per-conversation drafts and temporary chats (0.3.2)
Files: Core DraftState/ConversationStore/ChatEngine, Runtime/RootView/ChatView/Sidebar, tests/UI/fixture; release metadata.
Interfaces: protected per-account/per-chat draft store with migration; temporary conversation mode is memory-only and excluded from every persistence/outbox/search path. Leaving temporary chat explicitly discards it; ordinary chat switching restores each draft without discard alerts.
- [ ] RED: chat/account draft isolation and migration, attachments-ready draft references, save failure; temporary send/Stop/retry/revision never persists or syncs and cannot reappear after account change/relaunch.
- [ ] Implement mode/draft lifecycle and native controls/clear indicators, then suite GREEN.
- [ ] SDK UI tests plus server verifier confirms absence of temporary content; review, publish0.3.2 and verify source.

## Task 4 / 2.4: Photo/file attachments (0.3.3)
Files: Core ChatAttachment/AttachmentStore/provider request builders/WebChatCodec/DraftState/ChatEngine, native AttachmentImporter/ComposerAttachmentView, cloud sync, tests/UI/fixture; release metadata.
Interfaces: validated immutable attachment references with protected account files; bounded image/text/PDF support only where provider accepts it; native PhotosPicker/fileImporter, previews/removal/progress/errors; original web file metadata remains interoperable. Temporary attachment bytes stay in memory and are wiped when leaving.
- [ ] RED: file size/type/name/account validation, local draft/restoration, per-provider wire payloads and incompatible-model rejection before Send; remote attachments/context survive retries/edits; failed imports keep drafts.
- [ ] Implement native import/previews and provider uploads/body formats; meaningful Core tests GREEN.
- [ ] Real SDK fixture verifies attachment data and restoration; native picker/UI evidence where deterministic. Review, publish0.3.3 and verify source.

## Task 5 / 2.5: Long chats and interruption recovery (0.3.4)
Files: Core history paging/context window/outbox recovery, CloudChatSync, ChatView, protected draft/cache; Core tests/UI/fixture; release metadata.
Interfaces: stable page cursors based on authoritative ordered message IDs; load older on demand without replacing pending/current replies; bounded provider context with visible older-context indication; durable independent retry queue and selected chat restoration.
- [ ] RED: multi-page ordering/dedup/remote edits, pending turns on page loads, selected chat and interrupted reply restoration, bounded context preserving system/latest user, transient retry and one failing chat not blocking others.
- [ ] Implement paging/recovery and scroll-to-bottom control, then Core suite GREEN.
- [ ] Long fixture SDK/UI journey; full phase review, publish0.3.4 and verify source plus all five feed versions.

## Verification
Swift: /workspace/scratch/swift-6.2/usr/bin/swift test --package-path ios/LumenCore (baseline44 pass).
Python: python3 -m unittest discover -s ios/tests -p 'test_*.py' (baseline16 pass).
Swift frontend parse for UI syntax; actionlint for workflow changes. Native: committed build.sh/CI on both iPhone profiles, backend verifier, strict artifact pairing, public download hash/feed check. Real Google chooser/SideStore/live provider calls remain owner-device checks.
