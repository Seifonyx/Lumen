import Foundation
@main struct Repro {
 static func main() throws {
  let edited = ChatMessage(id: "edited-ID", role: .user, content: "Edited", attachmentNames: ["notes.txt"], sourceMessageID: "original-ID")
  var child = Conversation(id: "second-version", messages: [edited])
  child.parentConversationID = "first-version"
  let parentMessages: [String: [String: Any]] = ["edited-ID": ["role":"user", "text":"Edited", "files":[["name":"notes.txt", "text":"attachment bytes"]]]]
  var inherited: [String: [String: Any]] = [:]
  for local in child.messages {
   if let fields = parentMessages[local.sourceMessageID ?? local.id] { inherited[local.id] = fields }
  }
  let plan = try WebChatCodec.append(chat: child, messageIDs: [edited.id], remote: nil, existingMessages: [:], sourceMetadata: ["ids":["edited-ID"]], inheritedMessages: inherited)
  print("Second revision accepted; inherited files present:", plan.messages[edited.id]?["files"] != nil)
  let beforeParent = try WebChatCodec.append(chat: child, messageIDs: [edited.id], remote: nil, existingMessages: [:], sourceMetadata: nil)
  print("Child before parent accepted; inherited files present:", beforeParent.messages[edited.id]?["files"] != nil)
 }
}
