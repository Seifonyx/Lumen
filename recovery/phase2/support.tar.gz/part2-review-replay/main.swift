import Foundation
@MainActor final class ReviewStore: ConversationStore {
 var snapshot = ChatSnapshot(conversations: [Conversation(id: "chat", title: "Initial", messages: [ChatMessage(role: .user, content: "Hello")])])
 var fail = false
 func load(accountID: String) throws -> ChatSnapshot { snapshot }
 func save(_ snapshot: ChatSnapshot, accountID: String) throws {
  if fail { throw CocoaError(.fileWriteOutOfSpace) }; self.snapshot = snapshot
 }
}
let store = ReviewStore()
let engine = ChatEngine(store: store)
engine.renameConversation(id: "chat", title: "Native A")
let applied = engine.pendingMetadata["chat"]!
var remote: [String: Any] = ["title": "Initial"]
remote.merge(try WebChatCodec.metadataPatch(applied, remote: remote)) { _, new in new }
store.fail = true
print("ACK saved:", engine.acknowledgeMetadata(chatID: "chat", operationID: applied.id))
remote["title"] = "Later web B"
store.fail = false
engine.setPinned(id: "chat", pinned: true)
let queued = engine.pendingMetadata["chat"]!
let replay = try WebChatCodec.metadataPatch(queued, remote: remote)
print("Operation changed:", applied.id != queued.id)
print("Pin operation writes title:", replay["title"] ?? "nil")
